# Smart Event Java Model Classes

This project implements the 17 model classes represented in `Smart_Event_CRC_Cards.pdf`.

## Package
`smart_event.model`

## Included classes
UserAccount (abstract), Administrator, EventStaff, RegisteredGuest, Event, Venue,
EventRegistration, QRPass, AttendanceRecord, OccupancyMonitor, Photo, PhotoGallery,
PhotoModeration, FinalAlbum, Notification, EventReport, and AuditLog.

The project also includes enums for event, registration, pass, attendance, photo,
moderation, album publishing, notification channel, and delivery states.

## Compile
From the `src/main/java` directory:

```bash
javac smart_event/model/*.java
```

## Design notes
- All instance fields are private.
- Each model class has a constructor.
- State is changed through public domain methods rather than direct field access.
- `UserAccount` is abstract; `Administrator`, `EventStaff`, and `RegisteredGuest` extend it.
- `AuditLog.AuditEntry` is an immutable nested value class created by `AuditLog`.
- The CRC cards specify responsibilities and collaborators, but not exact field lists,
  method signatures, or constructor parameters. Those details are reasonable implementation
  choices based on the responsibilities and are not claimed to be explicitly specified by the PDF.
- `passwordHash` is expected to be a securely generated hash supplied by the authentication layer.
- Notification delivery and photo capture/storage are represented at the model level; external
  services are responsible for the actual transport and camera/file operations.

## Validation and tests
All attendance state changes go through `OccupancyMonitor` (`checkIn`, `checkOut`,
`correctAttendance`, `changeMaximumCapacity`, `addAttendanceRecord`). `AttendanceRecord`'s
state-changing methods are package-private, so a record is read-only outside the model package.
Check-ins earlier than the event's scheduled start time are rejected (also for corrections and
added records), `Event.updateDetails` validates every input before assigning anything, and
`OccupancyMonitor` rejects non-finite warning thresholds (NaN, infinities). Guests and events are
compared by id (`userId`, `eventId`, `registrationId`), never by object reference.

Compile and run the tests from the project root:

```bash
mkdir -p out
javac -d out $(find src -name "*.java")
java -cp out smart_event.ValidationTest
```

The runner prints `Passed: N, Failed: M` and exits with code 1 if any test fails.

## Final validation patch
- Venue and user profile updates validate all inputs before assignment.
- One monitor per Event object and event ID within the same Venue object; venue reassignment is blocked after attachment.
- Attendance mutations require a private monitor-issued permit, even within the model package.
- Existing tests that constructed duplicate monitors now use independent fixtures; four regression tests were added.
- Scope: in-memory, single-threaded model; canonical event/venue instances must be maintained by the application. No database-wide uniqueness or concurrent admission guarantee is provided.

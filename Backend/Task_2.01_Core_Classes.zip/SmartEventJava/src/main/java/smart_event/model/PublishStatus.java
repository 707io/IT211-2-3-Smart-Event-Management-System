package smart_event.model;
public enum PublishStatus { UNPUBLISHED, PUBLISHED }

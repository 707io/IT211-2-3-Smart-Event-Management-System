package smart_event.model;
public enum EventStatus { PLANNED, OPEN, CLOSED, COMPLETED, CANCELLED }

package smart_event.model;
public enum PhotoStatus { PENDING, PUBLISHED, HIDDEN, REMOVED }

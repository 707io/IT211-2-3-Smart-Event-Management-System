package smart_event.model;
public enum PassStatus { ACTIVE, REVOKED, EXPIRED }

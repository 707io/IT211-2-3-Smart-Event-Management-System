package smart_event.model;

import java.time.LocalDate;
import java.time.LocalTime;

/** Stores event details, settings, and lifecycle state. */
public class Event {
    private final String eventId;
    private String name;
    private LocalDate date;
    private LocalTime startTime;
    private LocalTime endTime;
    private EventStatus status;
    private boolean registrationOpen;
    private boolean reEntryAllowed;
    private boolean cameraEnabled;
    private boolean galleryVisible;
    private Venue venue;
    private OccupancyMonitor occupancyMonitor;

    public Event(String eventId, String name, LocalDate date, LocalTime startTime,
                 LocalTime endTime, Venue venue, boolean reEntryAllowed,
                 boolean cameraEnabled, boolean galleryVisible) {
        this.eventId = UserAccount.requireText(eventId, "eventId");
        updateDetails(name, date, startTime, endTime);
        this.venue = java.util.Objects.requireNonNull(venue, "venue");
        this.reEntryAllowed = reEntryAllowed;
        this.cameraEnabled = cameraEnabled;
        this.galleryVisible = galleryVisible;
        this.status = EventStatus.PLANNED;
        this.registrationOpen = false;
    }

    public String getEventId() { return eventId; }
    public String getName() { return name; }
    public LocalDate getDate() { return date; }
    public LocalTime getStartTime() { return startTime; }
    public LocalTime getEndTime() { return endTime; }
    public EventStatus getStatus() { return status; }
    public boolean isRegistrationOpen() { return registrationOpen; }
    public boolean isReEntryAllowed() { return reEntryAllowed; }
    public boolean isCameraEnabled() { return cameraEnabled; }
    public boolean isGalleryVisible() { return galleryVisible; }
    public Venue getVenue() { return venue; }

    /**
     * Validates every input first and only then assigns the new values, so a rejected update
     * leaves the event exactly as it was.
     */
    public void updateDetails(String name, LocalDate date, LocalTime start, LocalTime end) {
        String validName = UserAccount.requireText(name, "name");
        LocalDate validDate = java.util.Objects.requireNonNull(date, "date");
        LocalTime validStart = java.util.Objects.requireNonNull(start, "startTime");
        LocalTime validEnd = java.util.Objects.requireNonNull(end, "endTime");
        if (!validEnd.isAfter(validStart)) throw new IllegalArgumentException("End time must follow start time.");
        this.name = validName;
        this.date = validDate;
        this.startTime = validStart;
        this.endTime = validEnd;
    }

    public void updateSettings(boolean reEntryAllowed, boolean cameraEnabled, boolean galleryVisible) {
        this.reEntryAllowed = reEntryAllowed;
        this.cameraEnabled = cameraEnabled;
        this.galleryVisible = galleryVisible;
    }

    public synchronized void assignVenue(Venue venue) {
        java.util.Objects.requireNonNull(venue, "venue");
        if (occupancyMonitor != null && this.venue != venue)
            throw new IllegalStateException("Cannot change venue after an occupancy monitor is attached.");
        this.venue = venue;
    }
    synchronized void attachMonitor(OccupancyMonitor monitor) {
        if (occupancyMonitor != null) throw new IllegalStateException("Event already has an occupancy monitor.");
        if (monitor.getVenue() != venue) throw new IllegalArgumentException("Venue does not match event.");
        venue.attachMonitor(monitor);
        occupancyMonitor = monitor;
    }
    public void openRegistration() { registrationOpen = true; }
    public void closeRegistration() { registrationOpen = false; }
    public void startEvent() {
        if (status == EventStatus.CANCELLED || status == EventStatus.COMPLETED)
            throw new IllegalStateException("This event cannot be started.");
        status = EventStatus.OPEN;
    }
    public void closeEvent() { status = EventStatus.COMPLETED; registrationOpen = false; }
    public void cancelEvent() { status = EventStatus.CANCELLED; registrationOpen = false; }
}

package smart_event.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Holds approved photos for the post-event album. */
public class FinalAlbum {
    private final String albumId;
    private final Event event;
    private final List<Photo> approvedPhotos;
    private PublishStatus publishStatus;

    public FinalAlbum(String albumId, Event event, List<Photo> approvedPhotos) {
        this.albumId = UserAccount.requireText(albumId, "albumId");
        this.event = java.util.Objects.requireNonNull(event, "event");
        this.approvedPhotos = new ArrayList<>();
        if (approvedPhotos != null) {
            for (Photo photo : approvedPhotos) addApprovedPhoto(photo);
        }
        this.publishStatus = PublishStatus.UNPUBLISHED;
    }

    public String getAlbumId() { return albumId; }
    public Event getEvent() { return event; }
    public PublishStatus getPublishStatus() { return publishStatus; }
    public List<Photo> preview() { return Collections.unmodifiableList(approvedPhotos); }
    public void addApprovedPhoto(Photo photo) {
        if (photo == null || !photo.getEvent().equals(event) || photo.getStatus() != PhotoStatus.PUBLISHED)
            throw new IllegalArgumentException("Only published photos from this event can be added.");
        if (!approvedPhotos.contains(photo)) approvedPhotos.add(photo);
    }
    public void publish(Administrator administrator) {
        if (administrator == null || !administrator.canPublishAlbum())
            throw new SecurityException("Administrator is not authorized to publish the album.");
        publishStatus = PublishStatus.PUBLISHED;
    }
    public void unpublish(Administrator administrator) {
        if (administrator == null || !administrator.canPublishAlbum())
            throw new SecurityException("Administrator is not authorized to unpublish the album.");
        publishStatus = PublishStatus.UNPUBLISHED;
    }
}

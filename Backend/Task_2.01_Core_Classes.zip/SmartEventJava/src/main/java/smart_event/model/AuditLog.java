package smart_event.model;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Records important actions and corrections, including who, what, when, and why. */
public class AuditLog {
    private final List<AuditEntry> entries;

    public AuditLog() { entries = new ArrayList<>(); }

    public List<AuditEntry> getEntries() {
        return Collections.unmodifiableList(entries);
    }

    public void recordAction(UserAccount actor, String actionType, String description, String reason) {
        entries.add(new AuditEntry(actor, actionType, description, reason, LocalDateTime.now()));
    }

    public List<AuditEntry> search(String keyword) {
        if (keyword == null || keyword.isBlank()) return getEntries();
        List<AuditEntry> matches = new ArrayList<>();
        for (AuditEntry entry : entries) {
            String text = (entry.getActionType() + " " + entry.getDescription() + " " + entry.getReason())
                    .toLowerCase();
            if (text.contains(keyword.toLowerCase())) matches.add(entry);
        }
        return Collections.unmodifiableList(matches);
    }

    public static class AuditEntry {
        private final UserAccount actor;
        private final String actionType;
        private final String description;
        private final String reason;
        private final LocalDateTime timestamp;

        private AuditEntry(UserAccount actor, String actionType, String description,
                           String reason, LocalDateTime timestamp) {
            this.actor = java.util.Objects.requireNonNull(actor, "actor");
            this.actionType = UserAccount.requireText(actionType, "actionType");
            this.description = UserAccount.requireText(description, "description");
            this.reason = UserAccount.requireText(reason, "reason");
            this.timestamp = java.util.Objects.requireNonNull(timestamp, "timestamp");
        }

        public UserAccount getActor() { return actor; }
        public String getActionType() { return actionType; }
        public String getDescription() { return description; }
        public String getReason() { return reason; }
        public LocalDateTime getTimestamp() { return timestamp; }
    }
}

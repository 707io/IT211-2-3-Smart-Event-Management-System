package smart_event.model;

import java.time.LocalDateTime;

/**
 * Records one visit and prevents a second active attendance record.
 *
 * <p>The state-changing methods ({@code checkIn}, {@code checkOut}, {@code correctAttendance}) are
 * package-private on purpose: outside this package a record is read-only, so every attendance
 * state change has to go through {@link OccupancyMonitor}, which applies the event, capacity,
 * duplicate-entry, re-entry and QR validation.</p>
 */
public class AttendanceRecord {
    private final String recordId;
    private final EventRegistration registration;
    private LocalDateTime checkInTime;
    private LocalDateTime checkOutTime;
    private EntryMethod entryMethod;
    private RecordStatus recordStatus;

    public AttendanceRecord(String recordId, EventRegistration registration, EntryMethod entryMethod) {
        this.recordId = UserAccount.requireText(recordId, "recordId");
        this.registration = java.util.Objects.requireNonNull(registration, "registration");
        this.entryMethod = java.util.Objects.requireNonNull(entryMethod, "entryMethod");
        this.recordStatus = RecordStatus.ACTIVE;
    }

    public String getRecordId() { return recordId; }
    public EventRegistration getRegistration() { return registration; }
    public LocalDateTime getCheckInTime() { return checkInTime; }
    public LocalDateTime getCheckOutTime() { return checkOutTime; }
    public EntryMethod getEntryMethod() { return entryMethod; }
    public RecordStatus getRecordStatus() { return recordStatus; }

    /** True while the guest is inside: checked in and not yet checked out (even after a correction). */
    public boolean isInside() { return checkInTime != null && checkOutTime == null; }
    public boolean isActive() { return isInside(); }

    /** Package-private: only OccupancyMonitor may change attendance state. */
    void checkIn(OccupancyMonitor.MutationPermit permit, LocalDateTime time) {
        java.util.Objects.requireNonNull(permit, "monitor permit");
        java.util.Objects.requireNonNull(time, "time");
        if (!registration.isValid()) throw new IllegalStateException("Registration is not valid.");
        if (isInside()) throw new IllegalStateException("An active attendance record already exists.");
        if (checkInTime != null)
            throw new IllegalStateException("This visit is already completed; a new record is required for re-entry.");
        checkInTime = time;
        checkOutTime = null;
        recordStatus = RecordStatus.ACTIVE;
    }
    /** Package-private: only OccupancyMonitor may change attendance state. */
    void checkOut(OccupancyMonitor.MutationPermit permit, LocalDateTime time) {
        java.util.Objects.requireNonNull(permit, "monitor permit");
        java.util.Objects.requireNonNull(time, "time");
        if (checkInTime == null) throw new IllegalStateException("Cannot check out before check-in.");
        if (checkOutTime != null) throw new IllegalStateException("Duplicate check-out: guest already checked out.");
        if (time.isBefore(checkInTime)) throw new IllegalArgumentException("Check-out cannot precede check-in.");
        checkOutTime = time;
        recordStatus = RecordStatus.COMPLETED;
    }
    /** Package-private: only OccupancyMonitor may change attendance state. */
    void correctAttendance(OccupancyMonitor.MutationPermit permit, LocalDateTime checkIn, LocalDateTime checkOut,
                           EntryMethod method, String reason) {
        java.util.Objects.requireNonNull(permit, "monitor permit");
        UserAccount.requireText(reason, "reason");
        java.util.Objects.requireNonNull(method, "method");
        if (checkIn == null && checkOut != null)
            throw new IllegalArgumentException("Check-out requires a check-in time.");
        if (checkIn != null && checkOut != null && checkOut.isBefore(checkIn))
            throw new IllegalArgumentException("Check-out cannot precede check-in.");
        checkInTime = checkIn;
        checkOutTime = checkOut;
        entryMethod = method;
        recordStatus = RecordStatus.CORRECTED;
    }
}

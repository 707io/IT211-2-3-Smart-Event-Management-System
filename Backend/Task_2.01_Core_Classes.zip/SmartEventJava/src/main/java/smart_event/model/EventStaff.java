package smart_event.model;

/** User role responsible for event operations and attendance. */
public class EventStaff extends UserAccount {
    private String eventRole;

    public EventStaff(String userId, String username, String email, String fullName,
                      String passwordHash, String eventRole) {
        super(userId, username, email, fullName, passwordHash);
        this.eventRole = requireText(eventRole, "eventRole");
    }

    public String getEventRole() { return eventRole; }
    public void changeEventRole(String eventRole) {
        this.eventRole = requireText(eventRole, "eventRole");
    }
}

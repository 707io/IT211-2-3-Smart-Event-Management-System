package smart_event.model;

/** Abstract parent class shared by all user roles. */
public abstract class UserAccount {
    private final String userId;
    private String username;
    private String email;
    private String fullName;
    private String passwordHash;
    private boolean loggedIn;

    protected UserAccount(String userId, String username, String email,
                          String fullName, String passwordHash) {
        this.userId = requireText(userId, "userId");
        this.username = requireText(username, "username");
        this.email = requireText(email, "email");
        this.fullName = requireText(fullName, "fullName");
        this.passwordHash = requireText(passwordHash, "passwordHash");
        this.loggedIn = false;
    }

    public String getUserId() { return userId; }
    public String getUsername() { return username; }
    public String getEmail() { return email; }
    public String getFullName() { return fullName; }
    public boolean isLoggedIn() { return loggedIn; }

    public void login(String passwordHashAttempt) {
        if (passwordHash.equals(passwordHashAttempt)) loggedIn = true;
        else throw new IllegalArgumentException("Invalid credentials.");
    }

    public void logout() { loggedIn = false; }

    public void updateProfile(String username, String email, String fullName) {
        String validUsername = requireText(username, "username");
        String validEmail = requireText(email, "email");
        String validName = requireText(fullName, "fullName");
        this.username = validUsername;
        this.email = validEmail;
        this.fullName = validName;
    }

    public void changePassword(String currentPasswordHash, String newPasswordHash) {
        if (!passwordHash.equals(currentPasswordHash))
            throw new IllegalArgumentException("Current password is incorrect.");
        passwordHash = requireText(newPasswordHash, "newPasswordHash");
    }

    protected static String requireText(String value, String field) {
        if (value == null || value.isBlank())
            throw new IllegalArgumentException(field + " cannot be blank.");
        return value;
    }
}

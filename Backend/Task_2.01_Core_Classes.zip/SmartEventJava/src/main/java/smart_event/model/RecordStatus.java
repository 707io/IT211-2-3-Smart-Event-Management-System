package smart_event.model;
public enum RecordStatus { ACTIVE, COMPLETED, CORRECTED }

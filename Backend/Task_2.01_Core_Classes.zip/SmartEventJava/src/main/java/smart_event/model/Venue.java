package smart_event.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.function.IntSupplier;

/** Stores the event venue and its maximum capacity. */
public class Venue {
    private final String venueId;
    private String placeName;
    private String location;
    private int maximumCapacity;
    /** Suppliers of "how many people are inside right now", one per OccupancyMonitor using this venue. */
    private final List<IntSupplier> occupancyGuards = new ArrayList<>();

    public Venue(String venueId, String placeName, String location, int maximumCapacity) {
        this.venueId = UserAccount.requireText(venueId, "venueId");
        this.placeName = UserAccount.requireText(placeName, "placeName");
        this.location = UserAccount.requireText(location, "location");
        setMaximumCapacity(maximumCapacity);
    }

    public String getVenueId() { return venueId; }
    public String getPlaceName() { return placeName; }
    public String getLocation() { return location; }
    public int getMaximumCapacity() { return maximumCapacity; }

    public void updateDetails(String placeName, String location) {
        String validName = UserAccount.requireText(placeName, "placeName");
        String validLocation = UserAccount.requireText(location, "location");
        this.placeName = validName;
        this.location = validLocation;
    }

    /**
     * Registers a live occupancy source (normally an OccupancyMonitor). The capacity can never be
     * lowered below the occupancy reported by any registered source.
     */
    private final java.util.Set<String> monitoredEvents = new java.util.HashSet<>();
    synchronized void attachMonitor(OccupancyMonitor monitor) {
        if (!monitoredEvents.add(monitor.getEvent().getEventId()))
            throw new IllegalStateException("Event already has an occupancy monitor at this venue.");
        occupancyGuards.add(monitor::getCurrentOccupancy);
    }

    public void setMaximumCapacity(int capacity) {
        if (capacity < 1) throw new IllegalArgumentException("Capacity must be positive.");
        int inUse = 0;
        for (IntSupplier guard : occupancyGuards) inUse = Math.max(inUse, guard.getAsInt());
        if (capacity < inUse)
            throw new IllegalStateException("Capacity cannot be reduced to " + capacity
                    + " while " + inUse + " guest(s) are inside.");
        maximumCapacity = capacity;
    }
}

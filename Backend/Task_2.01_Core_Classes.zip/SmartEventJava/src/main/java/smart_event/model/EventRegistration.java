package smart_event.model;

/** Links one registered guest to one event and tracks registration/access status. */
public class EventRegistration {
    private final String registrationId;
    private final Event event;
    private final RegisteredGuest guest;
    private RegistrationStatus registrationStatus;
    private QRPass qrPass;

    public EventRegistration(String registrationId, Event event, RegisteredGuest guest,
                             RegistrationStatus registrationStatus) {
        this.registrationId = UserAccount.requireText(registrationId, "registrationId");
        this.event = java.util.Objects.requireNonNull(event, "event");
        this.guest = java.util.Objects.requireNonNull(guest, "guest");
        this.registrationStatus = java.util.Objects.requireNonNull(registrationStatus, "registrationStatus");
    }

    public String getRegistrationId() { return registrationId; }
    public Event getEvent() { return event; }
    public RegisteredGuest getGuest() { return guest; }
    public RegistrationStatus getRegistrationStatus() { return registrationStatus; }
    public QRPass getQrPass() { return qrPass; }
    public boolean isValid() {
        return registrationStatus == RegistrationStatus.REGISTERED
                && guest.isEligible() && event.getStatus() != EventStatus.CANCELLED;
    }

    public void approve() { registrationStatus = RegistrationStatus.REGISTERED; }
    public void markPending() { registrationStatus = RegistrationStatus.PENDING; }
    public void cancel() {
        registrationStatus = RegistrationStatus.CANCELLED;
        if (qrPass != null) qrPass.revoke();
    }
    public void revokeAccess() {
        if (qrPass != null) qrPass.revoke();
        registrationStatus = RegistrationStatus.CANCELLED;
    }
    public void assignPass(QRPass pass) {
        if (pass != null && pass.getRegistration() != this)
            throw new IllegalArgumentException("Pass belongs to a different registration.");
        qrPass = pass;
    }
}

package smart_event.model;

import java.time.LocalDateTime;

/** Represents a picture captured using the built-in camera. */
public class Photo {
    private final String photoId;
    private final Event event;
    private final RegisteredGuest capturedBy;
    private final LocalDateTime captureTime;
    private PhotoStatus status;
    private boolean downloadable;

    public Photo(String photoId, Event event, RegisteredGuest capturedBy,
                 LocalDateTime captureTime, boolean downloadable) {
        this.photoId = UserAccount.requireText(photoId, "photoId");
        this.event = java.util.Objects.requireNonNull(event, "event");
        this.capturedBy = java.util.Objects.requireNonNull(capturedBy, "capturedBy");
        this.captureTime = java.util.Objects.requireNonNull(captureTime, "captureTime");
        this.downloadable = downloadable;
        this.status = PhotoStatus.PENDING;
    }

    public String getPhotoId() { return photoId; }
    public Event getEvent() { return event; }
    public RegisteredGuest getCapturedBy() { return capturedBy; }
    public LocalDateTime getCaptureTime() { return captureTime; }
    public PhotoStatus getStatus() { return status; }
    public boolean isDownloadable() { return downloadable && status == PhotoStatus.PUBLISHED; }
    public void publish() { status = PhotoStatus.PUBLISHED; }
    public void hide() { status = PhotoStatus.HIDDEN; }
    public void remove() { status = PhotoStatus.REMOVED; }
    public void restore() { status = PhotoStatus.PUBLISHED; }
    public void setDownloadable(boolean allowed) { downloadable = allowed; }
}

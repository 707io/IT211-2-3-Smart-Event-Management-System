package smart_event.model;
public enum RegistrationStatus { PENDING, REGISTERED, CANCELLED }

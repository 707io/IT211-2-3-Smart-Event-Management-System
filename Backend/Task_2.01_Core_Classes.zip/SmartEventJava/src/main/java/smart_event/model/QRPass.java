package smart_event.model;

/** Holds and validates the unique event-specific QR pass. */
public class QRPass {
    private final String passId;
    private String code;
    private final EventRegistration registration;
    private PassStatus passStatus;

    public QRPass(String passId, String code, EventRegistration registration) {
        this.passId = UserAccount.requireText(passId, "passId");
        this.code = UserAccount.requireText(code, "code");
        this.registration = java.util.Objects.requireNonNull(registration, "registration");
        this.passStatus = PassStatus.ACTIVE;
    }

    public String getPassId() { return passId; }
    public String getCode() { return code; }
    public EventRegistration getRegistration() { return registration; }
    public PassStatus getPassStatus() { return passStatus; }

    /** Returns the reason this pass is not usable for the event, or null when it is valid. */
    public String validationError(Event selectedEvent) {
        if (selectedEvent == null) return "No event selected for QR validation.";
        if (passStatus == PassStatus.REVOKED) return "QR pass has been revoked.";
        if (passStatus == PassStatus.EXPIRED) return "QR pass has expired.";
        if (!registration.getEvent().getEventId().equals(selectedEvent.getEventId()))
            return "QR pass belongs to a different event.";
        if (!registration.isValid()) return "Registration behind this QR pass is not valid.";
        return null;
    }

    public boolean validate(Event selectedEvent) { return validationError(selectedEvent) == null; }

    /** Same as validate, but throws IllegalStateException with the reason when invalid. */
    public void requireValid(Event selectedEvent) {
        String error = validationError(selectedEvent);
        if (error != null) throw new IllegalStateException(error);
    }

    public void revoke() { passStatus = PassStatus.REVOKED; }
    public void reissue(String newCode) {
        code = UserAccount.requireText(newCode, "newCode");
        passStatus = PassStatus.ACTIVE;
    }
    public void expire() { passStatus = PassStatus.EXPIRED; }
}

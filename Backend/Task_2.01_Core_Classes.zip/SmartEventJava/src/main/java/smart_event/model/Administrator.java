package smart_event.model;

/** User role responsible for event administration and authorized publishing. */
public class Administrator extends UserAccount {
    private boolean canPublishAlbum;

    public Administrator(String userId, String username, String email,
                         String fullName, String passwordHash, boolean canPublishAlbum) {
        super(userId, username, email, fullName, passwordHash);
        this.canPublishAlbum = canPublishAlbum;
    }

    public boolean canPublishAlbum() { return canPublishAlbum; }
    public void setCanPublishAlbum(boolean allowed) { canPublishAlbum = allowed; }
}

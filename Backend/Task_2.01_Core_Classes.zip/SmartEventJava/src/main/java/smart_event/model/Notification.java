package smart_event.model;

/** Holds one guest message and its independent delivery status. */
public class Notification {
    private final String notificationId;
    private final RegisteredGuest recipient;
    private final String message;
    private final NotificationChannel channel;
    private DeliveryStatus deliveryStatus;
    private int deliveryAttempts;

    public Notification(String notificationId, RegisteredGuest recipient, String message,
                        NotificationChannel channel) {
        this.notificationId = UserAccount.requireText(notificationId, "notificationId");
        this.recipient = java.util.Objects.requireNonNull(recipient, "recipient");
        this.message = UserAccount.requireText(message, "message");
        this.channel = java.util.Objects.requireNonNull(channel, "channel");
        this.deliveryStatus = DeliveryStatus.PENDING;
        this.deliveryAttempts = 0;
    }

    public String getNotificationId() { return notificationId; }
    public RegisteredGuest getRecipient() { return recipient; }
    public String getMessage() { return message; }
    public NotificationChannel getChannel() { return channel; }
    public DeliveryStatus getDeliveryStatus() { return deliveryStatus; }
    public int getDeliveryAttempts() { return deliveryAttempts; }

    /** Marks a delivery attempt; the actual transport is handled by an external service. */
    public void recordDeliveryAttempt(boolean successful) {
        deliveryAttempts++;
        deliveryStatus = successful ? DeliveryStatus.SENT : DeliveryStatus.FAILED;
    }
    public void retry() {
        if (deliveryStatus == DeliveryStatus.SENT)
            throw new IllegalStateException("A successfully delivered notification cannot be retried.");
        deliveryStatus = DeliveryStatus.PENDING;
    }
}

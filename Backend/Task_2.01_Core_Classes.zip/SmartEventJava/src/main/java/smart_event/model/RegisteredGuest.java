package smart_event.model;

/** User role that registers for events and uses guest services. */
public class RegisteredGuest extends UserAccount {
    private String eligibilityStatus;

    public RegisteredGuest(String userId, String username, String email, String fullName,
                            String passwordHash, String eligibilityStatus) {
        super(userId, username, email, fullName, passwordHash);
        this.eligibilityStatus = requireText(eligibilityStatus, "eligibilityStatus");
    }

    public String getEligibilityStatus() { return eligibilityStatus; }
    public boolean isEligible() { return "ELIGIBLE".equalsIgnoreCase(eligibilityStatus); }
    public void updateEligibilityStatus(String status) {
        eligibilityStatus = requireText(status, "eligibilityStatus");
    }
}

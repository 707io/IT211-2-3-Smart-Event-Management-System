package smart_event.model;
public enum ModerationDecision { PENDING, APPROVED, HIDDEN, REMOVED, RESTORED }

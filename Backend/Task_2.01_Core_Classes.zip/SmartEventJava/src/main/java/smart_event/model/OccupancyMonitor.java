package smart_event.model;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

/**
 * Calculates occupancy and is the single gate for every attendance state change
 * (check-in, check-out, correction, capacity change) of one event.
 */
public class OccupancyMonitor {
    static final class MutationPermit { private MutationPermit() {} }
    private final MutationPermit permit = new MutationPermit();
    private final Event event;
    private final Venue venue;
    private final List<AttendanceRecord> attendanceRecords = new ArrayList<>();
    private final double warningThreshold;

    public OccupancyMonitor(Event event, Venue venue, List<AttendanceRecord> records,
                            double warningThreshold) {
        this.event = Objects.requireNonNull(event, "event");
        this.venue = Objects.requireNonNull(venue, "venue");
        if (venue != event.getVenue())
            throw new IllegalArgumentException("Venue does not match the event's venue.");
        // Double.isFinite rejects NaN and +/-Infinity, which would slip past plain <= / > comparisons.
        if (!Double.isFinite(warningThreshold) || warningThreshold <= 0 || warningThreshold > 1)
            throw new IllegalArgumentException("warningThreshold must be a finite number between 0 and 1.");
        this.warningThreshold = warningThreshold;
        if (records != null) for (AttendanceRecord r : records) addAttendanceRecord(r);
        // From now on the venue refuses a capacity lower than what is currently inside.
        event.attachMonitor(this);
    }

    public Event getEvent() { return event; }
    public Venue getVenue() { return venue; }
    public List<AttendanceRecord> getAttendanceRecords() {
        return Collections.unmodifiableList(attendanceRecords);
    }
    public int getCurrentOccupancy() {
        int count = 0;
        for (AttendanceRecord record : attendanceRecords) if (record.isInside()) count++;
        return count;
    }
    public int getRemainingPlaces() { return Math.max(0, venue.getMaximumCapacity() - getCurrentOccupancy()); }
    public boolean isNearCapacity() { return getCurrentOccupancy() >= Math.ceil(venue.getMaximumCapacity() * warningThreshold); }
    public boolean isFull() { return getCurrentOccupancy() >= venue.getMaximumCapacity(); }

    // ------------------------------------------------------------------ check-in

    /** Manual (staff) check-in. */
    public AttendanceRecord checkIn(EventRegistration registration, LocalDateTime time) {
        return checkIn(registration, EntryMethod.MANUAL, null, time);
    }

    /**
     * Checks a guest in. Rejects: wrong event, event not open, a time before the scheduled start,
     * an event that already ended, invalid registration,
     * missing/invalid/revoked QR pass (QR entry), guest already inside, re-entry when disabled,
     * and a full venue. Creates a new AttendanceRecord for every visit.
     */
    public AttendanceRecord checkIn(EventRegistration registration, EntryMethod method,
                                    QRPass presentedPass, LocalDateTime time) {
        Objects.requireNonNull(registration, "registration");
        Objects.requireNonNull(method, "method");
        Objects.requireNonNull(time, "time");

        requireSameEvent(registration);
        requireEventAcceptingCheckIn(time);
        if (!registration.isValid()) throw new IllegalStateException("Registration is not valid.");
        if (method == EntryMethod.QR_CODE) requireValidQrPass(registration, presentedPass);

        String guestId = registration.getGuest().getUserId();
        if (isGuestInside(guestId, null))
            throw new IllegalStateException("Guest already has an active check-in for this event.");
        if (!event.isReEntryAllowed() && visitCount(guestId, null) > 0)
            throw new IllegalStateException("Re-entry is not allowed for this event.");
        requireRoomForOneMore();

        AttendanceRecord record = new AttendanceRecord(nextRecordId(), registration, method);
        record.checkIn(permit, time);
        attendanceRecords.add(record);
        return record;
    }

    // ----------------------------------------------------------------- check-out

    public AttendanceRecord checkOut(EventRegistration registration, LocalDateTime time) {
        Objects.requireNonNull(registration, "registration");
        Objects.requireNonNull(time, "time");
        requireSameEvent(registration);

        String guestId = registration.getGuest().getUserId();
        AttendanceRecord latest = null;
        for (AttendanceRecord r : attendanceRecords) {
            if (!sameGuest(r, guestId)) continue;
            if (r.isInside()) { r.checkOut(permit, time); return r; }
            latest = r;
        }
        if (latest == null)
            throw new IllegalStateException("Cannot check out before check-in: no attendance record for this guest.");
        latest.checkOut(permit, time); // throws the precise error (duplicate check-out / before check-in)
        return latest;
    }

    // ---------------------------------------------------------------- corrections

    /** Corrects a record, refusing any result that breaks capacity, duplicate-entry or re-entry rules. */
    public void correctAttendance(String recordId, LocalDateTime checkIn, LocalDateTime checkOut,
                                  EntryMethod method, String reason) {
        AttendanceRecord record = findRecord(recordId);
        String guestId = record.getRegistration().getGuest().getUserId();
        boolean willBeInside = checkIn != null && checkOut == null;

        if (checkIn != null) requireNotBeforeScheduledStart(checkIn);
        if (willBeInside) {
            if (isGuestInside(guestId, record))
                throw new IllegalStateException("Correction would create a second active check-in for this guest.");
            int after = getCurrentOccupancy() - (record.isInside() ? 1 : 0) + 1;
            if (after > venue.getMaximumCapacity())
                throw new IllegalStateException("Correction would exceed venue capacity ("
                        + venue.getMaximumCapacity() + ").");
        }
        if (checkIn != null && !event.isReEntryAllowed() && visitCount(guestId, record) > 0)
            throw new IllegalStateException("Correction would create a re-entry, which is not allowed.");

        record.correctAttendance(permit, checkIn, checkOut, method, reason);
    }

    // ------------------------------------------------------------------- capacity

    /** Changes the venue capacity; refused when fewer than the guests currently inside. */
    public void changeMaximumCapacity(int newCapacity) {
        venue.setMaximumCapacity(newCapacity);
    }

    // -------------------------------------------------------------------- records

    /** Adds an existing record after the same checks check-in applies (event, duplicates, capacity). */
    public void addAttendanceRecord(AttendanceRecord record) {
        if (record == null) return;
        requireSameEvent(record.getRegistration());
        for (AttendanceRecord r : attendanceRecords) {
            if (r == record) return; // already tracked
            if (r.getRecordId().equals(record.getRecordId()))
                throw new IllegalArgumentException("A different attendance record already uses id " + record.getRecordId());
        }
        String guestId = record.getRegistration().getGuest().getUserId();
        if (record.getCheckInTime() != null) requireNotBeforeScheduledStart(record.getCheckInTime());
        if (record.isInside()) {
            if (isGuestInside(guestId, null))
                throw new IllegalStateException("Guest already has an active check-in for this event.");
            requireRoomForOneMore();
        }
        if (record.getCheckInTime() != null && !event.isReEntryAllowed() && visitCount(guestId, null) > 0)
            throw new IllegalStateException("Re-entry is not allowed for this event.");
        attendanceRecords.add(record);
    }

    // ------------------------------------------------------------------- helpers

    private void requireSameEvent(EventRegistration registration) {
        if (!registration.getEvent().getEventId().equals(event.getEventId()))
            throw new IllegalArgumentException("Registration belongs to a different event.");
    }

    private void requireEventAcceptingCheckIn(LocalDateTime time) {
        switch (event.getStatus()) {
            case OPEN -> { }
            case PLANNED -> throw new IllegalStateException("Event has not started yet.");
            case CLOSED, COMPLETED -> throw new IllegalStateException("Event has already ended.");
            case CANCELLED -> throw new IllegalStateException("Event has been cancelled.");
        }
        requireNotBeforeScheduledStart(time);
        if (time.isAfter(LocalDateTime.of(event.getDate(), event.getEndTime())))
            throw new IllegalStateException("Event has already ended.");
    }

    /** A check-in time earlier than the scheduled start of the event is never valid. */
    private void requireNotBeforeScheduledStart(LocalDateTime checkInTime) {
        if (checkInTime.isBefore(LocalDateTime.of(event.getDate(), event.getStartTime())))
            throw new IllegalStateException("Check-in is before the scheduled event start time.");
    }

    private void requireValidQrPass(EventRegistration registration, QRPass pass) {
        if (pass == null) throw new IllegalStateException("A QR pass is required for QR entry.");
        if (!pass.getRegistration().getRegistrationId().equals(registration.getRegistrationId())
                || registration.getQrPass() != pass)
            throw new IllegalStateException("QR pass does not belong to this registration.");
        pass.requireValid(event);
    }

    private void requireRoomForOneMore() {
        if (venue != event.getVenue())
            throw new IllegalStateException("Event venue changed; create a new OccupancyMonitor.");
        if (getCurrentOccupancy() >= venue.getMaximumCapacity())
            throw new IllegalStateException("Venue is full.");
    }

    private boolean sameGuest(AttendanceRecord r, String guestId) {
        return r.getRegistration().getGuest().getUserId().equals(guestId);
    }

    private boolean isGuestInside(String guestId, AttendanceRecord exclude) {
        for (AttendanceRecord r : attendanceRecords)
            if (r != exclude && sameGuest(r, guestId) && r.isInside()) return true;
        return false;
    }

    /** Number of visits (records with a check-in) of this guest, optionally ignoring one record. */
    private int visitCount(String guestId, AttendanceRecord exclude) {
        int n = 0;
        for (AttendanceRecord r : attendanceRecords)
            if (r != exclude && sameGuest(r, guestId) && r.getCheckInTime() != null) n++;
        return n;
    }

    private AttendanceRecord findRecord(String recordId) {
        for (AttendanceRecord r : attendanceRecords)
            if (r.getRecordId().equals(recordId)) return r;
        throw new IllegalArgumentException("Unknown attendance record: " + recordId);
    }

    private String nextRecordId() {
        int n = attendanceRecords.size() + 1;
        String id;
        do { id = event.getEventId() + "-AR-" + n++; } while (hasRecordId(id));
        return id;
    }

    private boolean hasRecordId(String id) {
        for (AttendanceRecord r : attendanceRecords) if (r.getRecordId().equals(id)) return true;
        return false;
    }
}

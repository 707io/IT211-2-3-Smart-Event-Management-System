package smart_event.model;
public enum EntryMethod { QR_CODE, MANUAL }

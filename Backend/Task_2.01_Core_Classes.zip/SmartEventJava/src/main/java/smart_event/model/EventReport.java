package smart_event.model;

import java.time.LocalDateTime;

/** Stores event summary metrics and provides a simple exportable text report. */
public class EventReport {
    private final String reportId;
    private final Event event;
    private final LocalDateTime generatedAt;
    private int registeredCount;
    private int checkInCount;
    private int peakOccupancy;
    private int photoCount;

    public EventReport(String reportId, Event event, LocalDateTime generatedAt,
                       int registeredCount, int checkInCount, int peakOccupancy, int photoCount) {
        this.reportId = UserAccount.requireText(reportId, "reportId");
        this.event = java.util.Objects.requireNonNull(event, "event");
        this.generatedAt = java.util.Objects.requireNonNull(generatedAt, "generatedAt");
        updateMetrics(registeredCount, checkInCount, peakOccupancy, photoCount);
    }

    public String getReportId() { return reportId; }
    public Event getEvent() { return event; }
    public LocalDateTime getGeneratedAt() { return generatedAt; }
    public int getRegisteredCount() { return registeredCount; }
    public int getCheckInCount() { return checkInCount; }
    public int getPeakOccupancy() { return peakOccupancy; }
    public int getPhotoCount() { return photoCount; }

    public void updateMetrics(int registered, int checkIns, int peak, int photos) {
        if (registered < 0 || checkIns < 0 || peak < 0 || photos < 0)
            throw new IllegalArgumentException("Report metrics cannot be negative.");
        registeredCount = registered;
        checkInCount = checkIns;
        peakOccupancy = peak;
        photoCount = photos;
    }
    public String generate() {
        return "Event Report: " + event.getName() + System.lineSeparator()
                + "Generated: " + generatedAt + System.lineSeparator()
                + "Registered: " + registeredCount + System.lineSeparator()
                + "Check-ins: " + checkInCount + System.lineSeparator()
                + "Peak occupancy: " + peakOccupancy + System.lineSeparator()
                + "Photos: " + photoCount;
    }
    public String export() { return generate(); }
}

package smart_event.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Holds the shared live gallery for one event. */
public class PhotoGallery {
    private final Event event;
    private final List<Photo> photos;
    private boolean accessRuleRequiresRegistration;

    public PhotoGallery(Event event, List<Photo> photos, boolean accessRuleRequiresRegistration) {
        this.event = java.util.Objects.requireNonNull(event, "event");
        this.photos = new ArrayList<>(photos == null ? List.of() : photos);
        this.accessRuleRequiresRegistration = accessRuleRequiresRegistration;
    }

    public Event getEvent() { return event; }
    public boolean isAccessRuleRequiresRegistration() { return accessRuleRequiresRegistration; }
    public void updateAccessRule(boolean requiresRegistration) {
        accessRuleRequiresRegistration = requiresRegistration;
    }
    public List<Photo> listPublishedPhotos() {
        List<Photo> result = new ArrayList<>();
        for (Photo photo : photos)
            if (photo.getStatus() == PhotoStatus.PUBLISHED) result.add(photo);
        return Collections.unmodifiableList(result);
    }
    public boolean checkAccess(RegisteredGuest guest, EventRegistration registration) {
        if (!event.isGalleryVisible() || guest == null) return false;
        if (!accessRuleRequiresRegistration) return true;
        return registration != null && registration.getGuest().equals(guest)
                && registration.getEvent().equals(event) && registration.isValid();
    }
    public void addPhoto(Photo photo) {
        if (photo == null || !photo.getEvent().equals(event))
            throw new IllegalArgumentException("Photo must belong to this event.");
        if (!photos.contains(photo)) photos.add(photo);
    }
}

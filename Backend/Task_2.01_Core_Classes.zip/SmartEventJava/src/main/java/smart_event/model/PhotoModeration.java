package smart_event.model;

import java.time.LocalDateTime;

/** Stores a review record and applies moderation decisions to a photo. */
public class PhotoModeration {
    private final String reviewId;
    private final Photo photo;
    private final UserAccount reporter;
    private final String reason;
    private final LocalDateTime reviewTime;
    private ModerationDecision decision;
    private Administrator reviewer;

    public PhotoModeration(String reviewId, Photo photo, UserAccount reporter,
                           String reason, LocalDateTime reviewTime) {
        this.reviewId = UserAccount.requireText(reviewId, "reviewId");
        this.photo = java.util.Objects.requireNonNull(photo, "photo");
        this.reporter = java.util.Objects.requireNonNull(reporter, "reporter");
        this.reason = UserAccount.requireText(reason, "reason");
        this.reviewTime = java.util.Objects.requireNonNull(reviewTime, "reviewTime");
        this.decision = ModerationDecision.PENDING;
    }

    public String getReviewId() { return reviewId; }
    public Photo getPhoto() { return photo; }
    public UserAccount getReporter() { return reporter; }
    public String getReason() { return reason; }
    public LocalDateTime getReviewTime() { return reviewTime; }
    public ModerationDecision getDecision() { return decision; }
    public Administrator getReviewer() { return reviewer; }

    public void approve(Administrator admin) {
        reviewer = requireAdmin(admin); photo.publish(); decision = ModerationDecision.APPROVED;
    }
    public void hide(Administrator admin) {
        reviewer = requireAdmin(admin); photo.hide(); decision = ModerationDecision.HIDDEN;
    }
    public void remove(Administrator admin) {
        reviewer = requireAdmin(admin); photo.remove(); decision = ModerationDecision.REMOVED;
    }
    public void restore(Administrator admin) {
        reviewer = requireAdmin(admin); photo.restore(); decision = ModerationDecision.RESTORED;
    }
    private Administrator requireAdmin(Administrator admin) {
        return java.util.Objects.requireNonNull(admin, "admin");
    }
}

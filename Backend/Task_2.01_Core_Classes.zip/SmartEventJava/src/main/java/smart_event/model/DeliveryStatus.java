package smart_event.model;
public enum DeliveryStatus { PENDING, SENT, FAILED }

package smart_event.model;
public enum NotificationChannel { EMAIL, SMS, IN_APP }

# Task 2.01 — Core classes with private fields
Smart Event Management System | BSIT 2-3 | Group 9

This package preserves the patched Task 2.02 source without changes to model behavior.

Verification: all 17 top-level model classes have private declared fields and constructors (reflection check). Public read methods were inspected; boolean queries and controlled collection views serve as accessors. Password hash and internal coordination fields intentionally have no public getter. The 17 class names and private field names/types match the Task 1.07 DOT diagram; selected operations and relationships remain subject to team review. The diagram intentionally omits routine getters and constructors. Ten enum types are supporting types, not additional model classes.

ValidationTest: 78 passed, 0 failed after compilation.

From the project root (Bash):
```sh
mkdir -p out
javac -d out $(find src -name '*.java')
java -cp out smart_event.ValidationTest
java -cp out CoreClassCheck Administrator AttendanceRecord AuditLog Event EventRegistration EventReport EventStaff FinalAlbum Notification OccupancyMonitor Photo PhotoGallery PhotoModeration QRPass RegisteredGuest UserAccount Venue
```

GitHub submission and team approval remain pending. Use the same model source for Tasks 2.01 and 2.02.

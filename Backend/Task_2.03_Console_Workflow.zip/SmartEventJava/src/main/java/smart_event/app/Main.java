package smart_event.app;

public class Main {
    public static void main(String[] args) {
        new ConsoleMenu().run();
    }
}

package smart_event.app;

import java.util.Scanner;

public class ConsoleMenu {
    public void run() {
        try (Scanner input = new Scanner(System.in)) {
            System.out.println("=== SMART EVENT SYSTEM ===");
            System.out.println("1. Run event workflow once\n0. Exit");
            System.out.print("Choose an option: ");
            if (!input.hasNextLine()) return;
            switch (input.nextLine().trim()) {
                case "1": new SmartEventApplication().runWorkflow(); break;
                case "0": System.out.println("Goodbye."); break;
                default: System.out.println("Invalid option. Run again to retry.");
            }
        }
    }
}

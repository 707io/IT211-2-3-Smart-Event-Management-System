package smart_event.app;

import smart_event.model.*;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.UUID;

public class SmartEventApplication {
    public void runWorkflow() {
        // Fixed demo schedule: reproducible regardless of the current clock.
        LocalDate day = LocalDate.of(2026, 12, 1);
        Venue venue = new Venue("V1", "Gymnasium", "Sorsogon", 5);
        Event event = new Event("E1", "Tech Fest", day, LocalTime.of(9, 0),
                LocalTime.of(17, 0), venue, false, true, true);
        event.openRegistration();
        System.out.println("\nEvent: " + event.getName() + " | " + day);
        RegisteredGuest guest = new RegisteredGuest("G1", "demo", "demo@example.com",
                "Demo Guest", "demo-only-hash", "ELIGIBLE");
        EventRegistration registration = new EventRegistration("R1", event, guest,
                RegistrationStatus.REGISTERED);
        QRPass pass = new QRPass("P1", UUID.randomUUID().toString(), registration);
        registration.assignPass(pass);
        System.out.println("Registration: " + registration.getRegistrationStatus());
        System.out.println("QR pass issued: " + pass.getPassId());
        event.startEvent();
        OccupancyMonitor monitor = new OccupancyMonitor(event, venue, null, 0.8);
        pass.requireValid(event);
        System.out.println("QR pass validated.");
        showOccupancy(monitor);
        monitor.checkIn(registration, day.atTime(10, 0));
        System.out.println("Guest checked in.");
        showOccupancy(monitor);
        monitor.checkOut(registration, day.atTime(11, 0));
        System.out.println("Guest checked out.");
        showOccupancy(monitor);
        event.closeEvent();
        System.out.println("Event status: " + event.getStatus());
        System.out.println("Workflow completed.");
    }

    private void showOccupancy(OccupancyMonitor monitor) {
        System.out.println("Occupancy: " + monitor.getCurrentOccupancy()
                + " / " + monitor.getVenue().getMaximumCapacity()
                + " | Remaining: " + monitor.getRemainingPlaces());
    }
}


package smartevent;

public class ValidationTest {

    private static int passed = 0;
    private static int failed = 0;

    @FunctionalInterface
    private interface CheckedAction {
        void run() throws Exception;
    }

    public static void main(String[] args) {
        System.out.println("Passed: " + passed + ", Failed: " + failed);

        if (failed > 0) {
            System.exit(1);
        }
    }

    private static void check(String name, CheckedAction action) {
        try {
            action.run();
            passed++;
            System.out.println("PASS: " + name);
        } catch (Throwable t) {
            failed++;
            System.out.println("FAIL: " + name + " -> " + t.getMessage());
        }
    }

    private static void assertThrows(
            Class<? extends Throwable> expected,
            CheckedAction action) {

        try {
            action.run();
        } catch (Throwable actual) {
            if (expected.isInstance(actual)) {
                return;
            }

            throw new AssertionError(
                "Expected " + expected.getSimpleName()
                + " but got " + actual.getClass().getSimpleName()
            );
        }

        throw new AssertionError(
            "Expected " + expected.getSimpleName() + " to be thrown"
        );
    }
}

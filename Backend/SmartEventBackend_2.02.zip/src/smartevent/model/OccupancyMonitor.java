package smartevent.model;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class OccupancyMonitor {

    private final Venue venue;
    private final List<AttendanceRecord> attendanceRecords;

    private double warningThreshold;

    public OccupancyMonitor(Venue venue) {

        if (venue == null) {
            throw new IllegalArgumentException(
                "Venue is required."
            );
        }

        this.venue = venue;
        this.attendanceRecords = new ArrayList<>();
        this.warningThreshold = 0.80;
    }

    public Venue getVenue() {
        return venue;
    }

    public double getWarningThreshold() {
        return warningThreshold;
    }

    public List<AttendanceRecord> getAttendanceRecords() {
        return Collections.unmodifiableList(attendanceRecords);
    }

    public void setWarningThreshold(double warningThreshold) {

        if (Double.isNaN(warningThreshold)
            || warningThreshold <= 0
            || warningThreshold > 1) {
            throw new IllegalArgumentException(
                "Warning threshold must be greater than 0 and at most 1."
            );
        }

        this.warningThreshold = warningThreshold;
    }

    public AttendanceRecord checkIn(
        EventRegistration registration,
        AttendanceRecord.EntryMethod entryMethod,
        LocalDateTime checkInTime
    ) {
        if (registration == null || !registration.isValid()) {
            throw new IllegalArgumentException(
                "A valid event registration is required."
            );
        }

        if (registration.getEvent().getVenue() != venue) {
            throw new IllegalArgumentException(
                "Registration belongs to a different venue."
            );
        }

        if (entryMethod == null || checkInTime == null) {
            throw new IllegalArgumentException(
                "Entry method and check-in time are required."
            );
        }

        for (AttendanceRecord record : attendanceRecords) {
            if (record.getRegistration() == registration
                && record.isActive()) {
                throw new IllegalStateException(
                    "Guest already has an active attendance record."
                );
            }
        }

        if (getCurrentOccupancy() >= venue.getMaximumCapacity()) {
            throw new IllegalStateException(
                "Venue is already at full capacity."
            );
        }

        AttendanceRecord record = new AttendanceRecord(
            registration,
            entryMethod,
            checkInTime
        );

        attendanceRecords.add(record);

        return record;
    }

    public void checkOut(
        AttendanceRecord record,
        LocalDateTime checkOutTime
    ) {
        if (record == null || !attendanceRecords.contains(record)) {
            throw new IllegalArgumentException(
                "Attendance record does not belong to this monitor."
            );
        }

        record.checkOut(checkOutTime);
    }

    public int getCurrentOccupancy() {

        int occupancy = 0;

        for (AttendanceRecord record : attendanceRecords) {
            if (record.isActive()) {
                occupancy++;
            }
        }

        return occupancy;
    }

    public int getRemainingPlaces() {
        return venue.getMaximumCapacity() - getCurrentOccupancy();
    }

    public boolean isNearCapacity() {
        return getCurrentOccupancy()
            >= venue.getMaximumCapacity() * warningThreshold;
    }

    public boolean isFull() {
        return getCurrentOccupancy() >= venue.getMaximumCapacity();
    }

    public String getOccupancyWarning() {

        if (isFull()) {
            return "WARNING: Venue is at full capacity.";
        }

        if (isNearCapacity()) {
            return "WARNING: Venue is nearing capacity.";
        }

        return "Occupancy is normal.";
    }
}

package smartevent.model;

import java.time.LocalDate;
import java.time.LocalTime;

public class Event {

    public enum EventStatus {
        SCHEDULED,
        ACTIVE,
        CLOSED
    }

    private String name;
    private LocalDate date;
    private LocalTime startTime;
    private LocalTime endTime;
    private EventStatus status;
    private Venue venue;

    private boolean registrationOpen;
    private boolean reEntryAllowed;
    private boolean cameraEnabled;
    private boolean galleryVisible;

    public Event(
        String name,
        LocalDate date,
        LocalTime startTime,
        LocalTime endTime,
        Venue venue
    ) {
        setName(name);
        setDate(date);
        setStartTime(startTime);
        setEndTime(endTime);
        setVenue(venue);

        this.status = EventStatus.SCHEDULED;
        this.registrationOpen = false;
        this.reEntryAllowed = false;
        this.cameraEnabled = false;
        this.galleryVisible = false;
    }

    public String getName() {
        return name;
    }

    public LocalDate getDate() {
        return date;
    }

    public LocalTime getStartTime() {
        return startTime;
    }

    public LocalTime getEndTime() {
        return endTime;
    }

    public EventStatus getStatus() {
        return status;
    }

    public Venue getVenue() {
        return venue;
    }

    public boolean isRegistrationOpen() {
        return registrationOpen;
    }

    public boolean isReEntryAllowed() {
        return reEntryAllowed;
    }

    public boolean isCameraEnabled() {
        return cameraEnabled;
    }

    public boolean isGalleryVisible() {
        return galleryVisible;
    }

    public void setName(String name) {
        if (name == null || name.isBlank()) {
            throw new IllegalArgumentException(
                "Event name cannot be empty."
            );
        }
        this.name = name.trim();
    }

    public void setDate(LocalDate date) {
        if (date == null) {
            throw new IllegalArgumentException(
                "Event date is required."
            );
        }
        this.date = date;
    }

    public void setStartTime(LocalTime startTime) {
        if (startTime == null) {
            throw new IllegalArgumentException(
                "Start time is required."
            );
        }

        if (endTime != null && !endTime.isAfter(startTime)) {
            throw new IllegalArgumentException(
                "End time must be after start time."
            );
        }

        this.startTime = startTime;
    }

    public void setEndTime(LocalTime endTime) {
        if (endTime == null) {
            throw new IllegalArgumentException(
                "End time is required."
            );
        }

        if (startTime != null && !endTime.isAfter(startTime)) {
            throw new IllegalArgumentException(
                "End time must be after start time."
            );
        }

        this.endTime = endTime;
    }

    public void setVenue(Venue venue) {
        if (venue == null) {
            throw new IllegalArgumentException(
                "Event must have a venue."
            );
        }
        this.venue = venue;
    }

    public void setReEntryAllowed(boolean allowed) {
        this.reEntryAllowed = allowed;
    }

    public void setCameraEnabled(boolean enabled) {
        this.cameraEnabled = enabled;
    }

    public void setGalleryVisible(boolean visible) {
        this.galleryVisible = visible;
    }

    public void openRegistration() {
        if (status == EventStatus.CLOSED) {
            throw new IllegalStateException(
                "Cannot open registration for a closed event."
            );
        }

        if (registrationOpen) {
            throw new IllegalStateException(
                "Registration is already open."
            );
        }

        registrationOpen = true;
    }

    public void closeRegistration() {
        if (!registrationOpen) {
            throw new IllegalStateException(
                "Registration is already closed."
            );
        }

        registrationOpen = false;
    }

    public void startEvent() {
        if (status != EventStatus.SCHEDULED) {
            throw new IllegalStateException(
                "Only scheduled events can be started."
            );
        }

        status = EventStatus.ACTIVE;
    }

    public void closeEvent() {
        if (status != EventStatus.ACTIVE) {
            throw new IllegalStateException(
                "Only active events can be closed."
            );
        }

        status = EventStatus.CLOSED;
        registrationOpen = false;
    }
}


package smartevent.model;

import java.time.LocalDateTime;

public class AttendanceRecord {

    public enum EntryMethod {
        QR_SCAN,
        MANUAL
    }

    private final EventRegistration registration;
    private LocalDateTime checkInTime;
    private LocalDateTime checkOutTime;
    private EntryMethod entryMethod;

    public AttendanceRecord(
        EventRegistration registration,
        EntryMethod entryMethod,
        LocalDateTime checkInTime
    ) {
        if (registration == null || !registration.isValid()) {
            throw new IllegalArgumentException(
                "A valid registration is required."
            );
        }

        if (entryMethod == null) {
            throw new IllegalArgumentException(
                "Entry method is required."
            );
        }

        if (checkInTime == null) {
            throw new IllegalArgumentException(
                "Check-in time is required."
            );
        }

        this.registration = registration;
        this.entryMethod = entryMethod;
        this.checkInTime = checkInTime;
        this.checkOutTime = null;
    }

    public EventRegistration getRegistration() {
        return registration;
    }

    public LocalDateTime getCheckInTime() {
        return checkInTime;
    }

    public LocalDateTime getCheckOutTime() {
        return checkOutTime;
    }

    public EntryMethod getEntryMethod() {
        return entryMethod;
    }

    public boolean isActive() {
        return checkOutTime == null;
    }

    public void checkOut(LocalDateTime checkOutTime) {

        if (!isActive()) {
            throw new IllegalStateException(
                "This attendance record is already checked out."
            );
        }

        if (checkOutTime == null) {
            throw new IllegalArgumentException(
                "Check-out time is required."
            );
        }

        if (checkOutTime.isBefore(this.checkInTime)) {
            throw new IllegalArgumentException(
                "Check-out cannot be before check-in."
            );
        }

        this.checkOutTime = checkOutTime;
    }

    public void correctTimes(
        LocalDateTime newCheckInTime,
        LocalDateTime newCheckOutTime,
        Administrator authorizedBy,
        String reason
    ) {
        if (authorizedBy == null) {
            throw new IllegalArgumentException(
                "Administrator authorization is required."
            );
        }

        if (reason == null || reason.isBlank()) {
            throw new IllegalArgumentException(
                "A correction reason is required."
            );
        }

        if (newCheckInTime == null) {
            throw new IllegalArgumentException(
                "Corrected check-in time is required."
            );
        }

        if (newCheckOutTime != null
            && newCheckOutTime.isBefore(newCheckInTime)) {

            throw new IllegalArgumentException(
                "Check-out cannot be before check-in."
            );
        }

        // Apply changes only after all validations pass.
        this.checkInTime = newCheckInTime;
        this.checkOutTime = newCheckOutTime;
    }
}

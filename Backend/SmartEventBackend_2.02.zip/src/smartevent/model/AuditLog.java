
package smartevent.model;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

public class AuditLog {

    public static class AuditEntry {

        private final String username;
        private final String action;
        private final LocalDateTime timestamp;
        private final String reason;

        private AuditEntry(
            String username,
            String action,
            LocalDateTime timestamp,
            String reason
        ) {
            this.username = username;
            this.action = action;
            this.timestamp = timestamp;
            this.reason = reason;
        }

        public String getUsername() {
            return username;
        }

        public String getAction() {
            return action;
        }

        public LocalDateTime getTimestamp() {
            return timestamp;
        }

        public String getReason() {
            return reason;
        }
    }

    private final List<AuditEntry> entries;

    public AuditLog() {
        this.entries = new ArrayList<>();
    }

    public void recordAction(
        UserAccount actor,
        String action,
        LocalDateTime timestamp
    ) {
        record(actor, action, timestamp, null);
    }

    public void recordCorrection(
        UserAccount actor,
        String action,
        LocalDateTime timestamp,
        String reason
    ) {
        if (reason == null || reason.isBlank()) {
            throw new IllegalArgumentException(
                "Correction reason is required."
            );
        }

        record(actor, action, timestamp, reason.trim());
    }

    private void record(
        UserAccount actor,
        String action,
        LocalDateTime timestamp,
        String reason
    ) {
        if (actor == null) {
            throw new IllegalArgumentException(
                "Action performer is required."
            );
        }

        if (action == null || action.isBlank()) {
            throw new IllegalArgumentException(
                "Action description cannot be empty."
            );
        }

        if (timestamp == null) {
            throw new IllegalArgumentException(
                "Action timestamp is required."
            );
        }

        entries.add(new AuditEntry(
            actor.getUsername(),
            action.trim(),
            timestamp,
            reason
        ));
    }

    public List<AuditEntry> searchHistory(
        Administrator administrator
    ) {
        if (administrator == null) {
            throw new SecurityException(
                "Only administrators can search audit history."
            );
        }

        return Collections.unmodifiableList(
            new ArrayList<>(entries)
        );
    }

    public List<AuditEntry> searchByAction(
        Administrator administrator,
        String action
    ) {
        if (administrator == null) {
            throw new SecurityException(
                "Only administrators can search audit history."
            );
        }

        if (action == null || action.isBlank()) {
            throw new IllegalArgumentException(
                "Search action cannot be empty."
            );
        }

        String searchTerm = action.trim().toLowerCase(Locale.ROOT);

        List<AuditEntry> results = new ArrayList<>();

        for (AuditEntry entry : entries) {
            if (entry.getAction().toLowerCase(Locale.ROOT)
                .contains(searchTerm)) {
                results.add(entry);
            }
        }

        return Collections.unmodifiableList(results);
    }

    public int getEntryCount() {
        return entries.size();
    }
}

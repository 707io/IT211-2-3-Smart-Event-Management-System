package smartevent.model;

public class Administrator extends UserAccount {

    public Administrator(String userId, String username, String displayName) {
        super(userId, username, displayName);
    }
}
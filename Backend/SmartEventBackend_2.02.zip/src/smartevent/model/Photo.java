
package smartevent.model;

import java.time.LocalDateTime;

public class Photo {

    public enum PhotoStatus {
        CAPTURED,
        PUBLISHED,
        HIDDEN,
        REMOVED
    }

    private final String photoId;
    private final RegisteredGuest owner;
    private final Event event;
    private final LocalDateTime captureTime;
    private PhotoStatus status;

    public Photo(
        String photoId,
        RegisteredGuest owner,
        Event event,
        LocalDateTime captureTime
    ) {
        if (photoId == null || photoId.isBlank()) {
            throw new IllegalArgumentException(
                "Photo ID cannot be empty."
            );
        }

        if (owner == null) {
            throw new IllegalArgumentException(
                "Photo owner is required."
            );
        }

        if (event == null) {
            throw new IllegalArgumentException(
                "Event is required."
            );
        }

        if (captureTime == null) {
            throw new IllegalArgumentException(
                "Capture time is required."
            );
        }

        this.photoId = photoId.trim();
        this.owner = owner;
        this.event = event;
        this.captureTime = captureTime;
        this.status = PhotoStatus.CAPTURED;
    }

    public String getPhotoId() {
        return photoId;
    }

    public RegisteredGuest getOwner() {
        return owner;
    }

    public Event getEvent() {
        return event;
    }

    public LocalDateTime getCaptureTime() {
        return captureTime;
    }

    public PhotoStatus getStatus() {
        return status;
    }

    public boolean isDownloadable() {
        return status == PhotoStatus.PUBLISHED
            && event.isGalleryVisible();
    }

    public void publish() {
        if (status != PhotoStatus.CAPTURED
            && status != PhotoStatus.HIDDEN) {
            throw new IllegalStateException(
                "Only captured or hidden photos can be published."
            );
        }

        status = PhotoStatus.PUBLISHED;
    }

    public void hide() {
        if (status != PhotoStatus.PUBLISHED) {
            throw new IllegalStateException(
                "Only published photos can be hidden."
            );
        }

        status = PhotoStatus.HIDDEN;
    }

    public void restore() {
        if (status != PhotoStatus.HIDDEN) {
            throw new IllegalStateException(
                "Only hidden photos can be restored."
            );
        }

        status = PhotoStatus.PUBLISHED;
    }

    public void remove() {
        if (status == PhotoStatus.REMOVED) {
            throw new IllegalStateException(
                "Photo has already been removed."
            );
        }

        status = PhotoStatus.REMOVED;
    }
}

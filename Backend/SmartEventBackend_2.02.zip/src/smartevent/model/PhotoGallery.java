
package smartevent.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class PhotoGallery {

    private final Event event;
    private final List<Photo> photos;

    public PhotoGallery(Event event) {

        if (event == null) {
            throw new IllegalArgumentException(
                "Gallery must belong to an event."
            );
        }

        this.event = event;
        this.photos = new ArrayList<>();
    }

    public Event getEvent() {
        return event;
    }

    public List<Photo> getPhotos() {
        return Collections.unmodifiableList(photos);
    }

    public List<Photo> getPublishedPhotos() {

        List<Photo> published = new ArrayList<>();

        for (Photo photo : photos) {
            if (photo.getStatus() == Photo.PhotoStatus.PUBLISHED) {
                published.add(photo);
            }
        }

        return Collections.unmodifiableList(published);
    }

    public void addPhoto(Photo photo) {

        if (photo == null) {
            throw new IllegalArgumentException(
                "Photo is required."
            );
        }

        if (photo.getEvent() != event) {
            throw new IllegalArgumentException(
                "Photo belongs to a different event."
            );
        }

        for (Photo existing : photos) {
            if (existing.getPhotoId().equals(photo.getPhotoId())) {
                throw new IllegalArgumentException(
                    "Photo ID already exists in this gallery."
                );
            }
        }

        photos.add(photo);
    }

    public boolean checkAccess(EventRegistration registration) {

        return registration != null
            && registration.getEvent() == event
            && registration.isValid()
            && event.isGalleryVisible();
    }

    public List<Photo> viewPhotos(EventRegistration registration) {

        if (!checkAccess(registration)) {
            throw new SecurityException(
                "Guest is not authorized to view this gallery."
            );
        }

        return getPublishedPhotos();
    }

    public boolean containsPhoto(Photo photo) {
        return photo != null && photos.contains(photo);
    }

    public int getPhotoCount() {
        return photos.size();
    }
}

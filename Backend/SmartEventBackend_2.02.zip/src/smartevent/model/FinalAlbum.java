
package smartevent.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class FinalAlbum {

    public enum PublishStatus {
        DRAFT,
        PUBLISHED,
        UNPUBLISHED
    }

    private final Event event;
    private final List<Photo> approvedPhotos;
    private PublishStatus publishStatus;

    public FinalAlbum(Event event) {

        if (event == null) {
            throw new IllegalArgumentException(
                "Final album must belong to an event."
            );
        }

        this.event = event;
        this.approvedPhotos = new ArrayList<>();
        this.publishStatus = PublishStatus.DRAFT;
    }

    public Event getEvent() {
        return event;
    }

    public PublishStatus getPublishStatus() {
        return publishStatus;
    }

    public List<Photo> getApprovedPhotos() {
        return Collections.unmodifiableList(approvedPhotos);
    }

    public int getPhotoCount() {
        return approvedPhotos.size();
    }

    public void addApprovedPhoto(Photo photo) {

        if (photo == null) {
            throw new IllegalArgumentException(
                "Photo is required."
            );
        }

        if (publishStatus == PublishStatus.PUBLISHED) {
            throw new IllegalStateException(
                "Unpublish the album before editing it."
            );
        }

        if (photo.getEvent() != event) {
            throw new IllegalArgumentException(
                "Photo belongs to a different event."
            );
        }

        if (photo.getStatus() != Photo.PhotoStatus.PUBLISHED) {
            throw new IllegalArgumentException(
                "Only published photos can enter the final album."
            );
        }

        for (Photo existing : approvedPhotos) {
            if (existing.getPhotoId().equals(photo.getPhotoId())) {
                throw new IllegalArgumentException(
                    "Photo is already in the final album."
                );
            }
        }

        approvedPhotos.add(photo);
    }

    public void removePhoto(Photo photo) {

        if (photo == null || !approvedPhotos.contains(photo)) {
            throw new IllegalArgumentException(
                "Photo is not in this album."
            );
        }

        if (publishStatus == PublishStatus.PUBLISHED) {
            throw new IllegalStateException(
                "Unpublish the album before editing it."
            );
        }

        approvedPhotos.remove(photo);
    }

    public List<Photo> preview() {
        return Collections.unmodifiableList(
            new ArrayList<>(approvedPhotos)
        );
    }

    public void publish(Administrator administrator) {

        if (administrator == null) {
            throw new IllegalArgumentException(
                "Administrator authorization is required."
            );
        }

        if (publishStatus == PublishStatus.PUBLISHED) {
            throw new IllegalStateException(
                "Album is already published."
            );
        }

        if (approvedPhotos.isEmpty()) {
            throw new IllegalStateException(
                "Cannot publish an empty album."
            );
        }

        publishStatus = PublishStatus.PUBLISHED;
    }

    public void unpublish(Administrator administrator) {

        if (administrator == null) {
            throw new IllegalArgumentException(
                "Administrator authorization is required."
            );
        }

        if (publishStatus != PublishStatus.PUBLISHED) {
            throw new IllegalStateException(
                "Album is not currently published."
            );
        }

        publishStatus = PublishStatus.UNPUBLISHED;
    }
}

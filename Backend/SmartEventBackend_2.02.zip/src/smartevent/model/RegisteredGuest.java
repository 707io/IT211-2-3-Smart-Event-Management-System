package smartevent.model;

public class RegisteredGuest extends UserAccount {

    public RegisteredGuest(String userId, String username, String displayName) {
        super(userId, username, displayName);
    }
}
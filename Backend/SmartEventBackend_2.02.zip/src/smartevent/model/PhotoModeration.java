
package smartevent.model;

import java.time.LocalDateTime;

public class PhotoModeration {

    public enum Decision {
        PENDING,
        APPROVED,
        HIDDEN,
        REMOVED,
        RESTORED
    }

    private final Photo photo;
    private final RegisteredGuest reporter;
    private final String reason;

    private Decision decision;
    private Administrator reviewedBy;
    private LocalDateTime reviewTime;

    public PhotoModeration(
        Photo photo,
        RegisteredGuest reporter,
        String reason
    ) {
        if (photo == null) {
            throw new IllegalArgumentException(
                "Reported photo is required."
            );
        }

        if (reporter == null) {
            throw new IllegalArgumentException(
                "Reporter is required."
            );
        }

        if (reason == null || reason.isBlank()) {
            throw new IllegalArgumentException(
                "Report reason cannot be empty."
            );
        }

        this.photo = photo;
        this.reporter = reporter;
        this.reason = reason.trim();
        this.decision = Decision.PENDING;
        this.reviewedBy = null;
        this.reviewTime = null;
    }

    public Photo getPhoto() {
        return photo;
    }

    public RegisteredGuest getReporter() {
        return reporter;
    }

    public String getReason() {
        return reason;
    }

    public Decision getDecision() {
        return decision;
    }

    public Administrator getReviewedBy() {
        return reviewedBy;
    }

    public LocalDateTime getReviewTime() {
        return reviewTime;
    }

    public void approve(
        Administrator administrator,
        LocalDateTime time
    ) {
        validateReview(administrator, time);

        if (photo.getStatus() == Photo.PhotoStatus.HIDDEN) {
            photo.restore();
        } else if (photo.getStatus() == Photo.PhotoStatus.CAPTURED) {
            photo.publish();
        } else {
            throw new IllegalStateException(
                "Photo cannot be approved in its current status."
            );
        }

        completeReview(
            administrator,
            time,
            Decision.APPROVED
        );
    }

    public void hide(
        Administrator administrator,
        LocalDateTime time
    ) {
        validateReview(administrator, time);

        photo.hide();

        completeReview(
            administrator,
            time,
            Decision.HIDDEN
        );
    }

    public void remove(
        Administrator administrator,
        LocalDateTime time
    ) {
        validateReview(administrator, time);

        photo.remove();

        completeReview(
            administrator,
            time,
            Decision.REMOVED
        );
    }

    public void restore(
        Administrator administrator,
        LocalDateTime time
    ) {
        validateReview(administrator, time);

        photo.restore();

        completeReview(
            administrator,
            time,
            Decision.RESTORED
        );
    }

    private void validateReview(
        Administrator administrator,
        LocalDateTime time
    ) {
        if (administrator == null) {
            throw new IllegalArgumentException(
                "Administrator authorization is required."
            );
        }

        if (time == null) {
            throw new IllegalArgumentException(
                "Review time is required."
            );
        }

        if (decision != Decision.PENDING) {
            throw new IllegalStateException(
                "This report has already been reviewed."
            );
        }
    }

    private void completeReview(
        Administrator administrator,
        LocalDateTime time,
        Decision finalDecision
    ) {
        this.reviewedBy = administrator;
        this.reviewTime = time;
        this.decision = finalDecision;
    }
}

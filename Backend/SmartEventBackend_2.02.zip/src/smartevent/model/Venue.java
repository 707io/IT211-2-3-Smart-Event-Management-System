package smartevent.model;

public class Venue {

    private String placeName;
    private String location;
    private int maximumCapacity;

    public Venue(String placeName, String location, int maximumCapacity) {
        setPlaceName(placeName);
        setLocation(location);
        setMaximumCapacity(maximumCapacity);
    }

    public String getPlaceName() {
        return placeName;
    }

    public String getLocation() {
        return location;
    }

    public int getMaximumCapacity() {
        return maximumCapacity;
    }

    public void setPlaceName(String placeName) {
        if (placeName == null || placeName.isBlank()) {
            throw new IllegalArgumentException(
                "Venue name cannot be empty."
            );
        }
        this.placeName = placeName.trim();
    }

    public void setLocation(String location) {
        if (location == null || location.isBlank()) {
            throw new IllegalArgumentException(
                "Venue location cannot be empty."
            );
        }
        this.location = location.trim();
    }

    public void setMaximumCapacity(int maximumCapacity) {
        if (maximumCapacity <= 0) {
            throw new IllegalArgumentException(
                "Venue capacity must be greater than zero."
            );
        }
        this.maximumCapacity = maximumCapacity;
    }
}

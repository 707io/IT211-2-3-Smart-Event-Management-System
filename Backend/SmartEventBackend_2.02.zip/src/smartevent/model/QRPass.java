package smartevent.model;

import java.util.UUID;

public class QRPass {

    public enum PassStatus {
        ACTIVE,
        REVOKED
    }

    private final String qrCode;
    private final EventRegistration registration;
    private PassStatus status;

    QRPass(EventRegistration registration) {

        if (registration == null || !registration.isValid()) {
            throw new IllegalArgumentException(
                "A valid registration is required for a QR pass."
            );
        }

        this.registration = registration;
        this.qrCode = UUID.randomUUID().toString();
        this.status = PassStatus.ACTIVE;
    }

    public String getQrCode() {
        return qrCode;
    }

    public EventRegistration getRegistration() {
        return registration;
    }

    public PassStatus getStatus() {
        return status;
    }

    public boolean isActive() {
        return status == PassStatus.ACTIVE;
    }

    public boolean isValidFor(Event selectedEvent) {

        return selectedEvent != null
            && registration.getEvent() == selectedEvent
            && registration.isValid()
            && isActive();
    }

    public void validateFor(Event selectedEvent) {

        if (selectedEvent == null) {
            throw new IllegalArgumentException(
                "Selected event is required."
            );
        }

        if (registration.getEvent() != selectedEvent) {
            throw new IllegalArgumentException(
                "QR pass does not belong to the selected event."
            );
        }

        if (!registration.isValid()) {
            throw new IllegalStateException(
                "Registration is not valid."
            );
        }

        if (!isActive()) {
            throw new IllegalStateException(
                "QR pass has been revoked."
            );
        }
    }

    public void revoke() {

        if (!isActive()) {
            throw new IllegalStateException(
                "QR pass is already revoked."
            );
        }

        status = PassStatus.REVOKED;
    }
}

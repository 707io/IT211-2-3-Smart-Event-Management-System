
package smartevent.model;

import java.time.LocalDateTime;

public class Notification {

    public enum Channel {
        EMAIL, SMS, IN_APP
    }

    public enum DeliveryStatus {
        PENDING, SENT, FAILED
    }

    private final RegisteredGuest recipient;
    private final String message;
    private final Channel channel;

    private DeliveryStatus deliveryStatus;
    private int attempts;
    private LocalDateTime lastAttemptTime;

    public Notification(
        RegisteredGuest recipient,
        String message,
        Channel channel
    ) {
        if (recipient == null) {
            throw new IllegalArgumentException(
                "Recipient is required."
            );
        }

        if (message == null || message.isBlank()) {
            throw new IllegalArgumentException(
                "Message cannot be empty."
            );
        }

        if (channel == null) {
            throw new IllegalArgumentException(
                "Channel is required."
            );
        }

        this.recipient = recipient;
        this.message = message.trim();
        this.channel = channel;
        this.deliveryStatus = DeliveryStatus.PENDING;
        this.attempts = 0;
        this.lastAttemptTime = null;
    }

    public RegisteredGuest getRecipient() {
        return recipient;
    }

    public String getMessage() {
        return message;
    }

    public Channel getChannel() {
        return channel;
    }

    public DeliveryStatus getDeliveryStatus() {
        return deliveryStatus;
    }

    public int getAttempts() {
        return attempts;
    }

    public LocalDateTime getLastAttemptTime() {
        return lastAttemptTime;
    }

    public void send(LocalDateTime time, boolean delivered) {

        if (deliveryStatus != DeliveryStatus.PENDING) {
            throw new IllegalStateException(
                "Only pending notifications can be sent initially."
            );
        }

        recordAttempt(time, delivered);
    }

    public void retry(LocalDateTime time, boolean delivered) {

        if (deliveryStatus != DeliveryStatus.FAILED) {
            throw new IllegalStateException(
                "Only failed notifications can be retried."
            );
        }

        recordAttempt(time, delivered);
    }

    private void recordAttempt(
        LocalDateTime time,
        boolean delivered
    ) {
        if (time == null) {
            throw new IllegalArgumentException(
                "Attempt time is required."
            );
        }

        if (lastAttemptTime != null
            && time.isBefore(lastAttemptTime)) {
            throw new IllegalArgumentException(
                "Attempt time cannot be before the previous attempt."
            );
        }

        attempts++;
        lastAttemptTime = time;

        deliveryStatus = delivered
            ? DeliveryStatus.SENT
            : DeliveryStatus.FAILED;
    }
}

package smartevent.model;

public abstract class UserAccount {

    private final String userId;
    private String username;
    private String displayName;
    private boolean loggedIn;

    public UserAccount(String userId, String username, String displayName) {

        if (userId == null || userId.isBlank()) {
            throw new IllegalArgumentException("User ID cannot be empty.");
        }

        this.userId = userId.trim();
        setUsername(username);
        setDisplayName(displayName);
        this.loggedIn = false;
    }

    public String getUserId() {
        return userId;
    }

    public String getUsername() {
        return username;
    }

    public String getDisplayName() {
        return displayName;
    }

    public boolean isLoggedIn() {
        return loggedIn;
    }

    public void setUsername(String username) {
        if (username == null || username.isBlank()) {
            throw new IllegalArgumentException("Username cannot be empty.");
        }

        this.username = username.trim();
    }

    public void setDisplayName(String displayName) {
        if (displayName == null || displayName.isBlank()) {
            throw new IllegalArgumentException("Display name cannot be empty.");
        }

        this.displayName = displayName.trim();
    }

    public void login() {
        if (loggedIn) {
            throw new IllegalStateException("User is already logged in.");
        }

        loggedIn = true;
    }

    public void logout() {
        if (!loggedIn) {
            throw new IllegalStateException("User is not logged in.");
        }

        loggedIn = false;
    }
}

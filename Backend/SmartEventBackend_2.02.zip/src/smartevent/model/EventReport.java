
package smartevent.model;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;

public class EventReport {

    private final Event event;
    private final int registeredGuests;
    private final int checkIns;
    private final int peakOccupancy;
    private final int photoCount;
    private final LocalDateTime generatedAt;

    public EventReport(
        Event event,
        int registeredGuests,
        int checkIns,
        int peakOccupancy,
        int photoCount
    ) {
        if (event == null) {
            throw new IllegalArgumentException(
                "Event is required."
            );
        }

        if (registeredGuests < 0
            || checkIns < 0
            || peakOccupancy < 0
            || photoCount < 0) {

            throw new IllegalArgumentException(
                "Report values cannot be negative."
            );
        }

        if (peakOccupancy > checkIns) {
            throw new IllegalArgumentException(
                "Peak occupancy cannot exceed total check-ins."
            );
        }

        this.event = event;
        this.registeredGuests = registeredGuests;
        this.checkIns = checkIns;
        this.peakOccupancy = peakOccupancy;
        this.photoCount = photoCount;
        this.generatedAt = LocalDateTime.now();
    }

    public Event getEvent() {
        return event;
    }

    public int getRegisteredGuests() {
        return registeredGuests;
    }

    public int getCheckIns() {
        return checkIns;
    }

    public int getPeakOccupancy() {
        return peakOccupancy;
    }

    public int getPhotoCount() {
        return photoCount;
    }

    public LocalDateTime getGeneratedAt() {
        return generatedAt;
    }

    public String generate() {

        return "========== EVENT REPORT ==========\n"
            + "Event: " + event.getName() + "\n"
            + "Date: " + event.getDate() + "\n"
            + "Registered Guests: " + registeredGuests + "\n"
            + "Total Check-ins: " + checkIns + "\n"
            + "Peak Occupancy: " + peakOccupancy + "\n"
            + "Photo Count: " + photoCount + "\n"
            + "Generated At: " + generatedAt + "\n"
            + "==================================";
    }

    public void export(Path filePath) throws IOException {

        if (filePath == null) {
            throw new IllegalArgumentException(
                "Export file path is required."
            );
        }

        Path absolutePath = filePath.toAbsolutePath();
        Path parent = absolutePath.getParent();

        if (parent != null) {
            Files.createDirectories(parent);
        }

        Files.writeString(absolutePath, generate());
    }
}

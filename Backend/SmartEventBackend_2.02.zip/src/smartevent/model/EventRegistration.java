package smartevent.model;

public class EventRegistration {

    public enum RegistrationStatus {
        PENDING,
        REGISTERED,
        CANCELLED
    }

    private final RegisteredGuest guest;
    private final Event event;
    private RegistrationStatus status;
    private QRPass qrPass;

    public EventRegistration(RegisteredGuest guest, Event event) {
        if (guest == null) {
            throw new IllegalArgumentException("Registered guest is required.");
        }

        if (event == null) {
            throw new IllegalArgumentException("Event is required.");
        }

        this.guest = guest;
        this.event = event;
        this.status = RegistrationStatus.PENDING;
    }

    public RegisteredGuest getGuest() {
        return guest;
    }

    public Event getEvent() {
        return event;
    }

    public RegistrationStatus getStatus() {
        return status;
    }

    public QRPass getQrPass() {
        return qrPass;
    }

    public boolean isValid() {
        return status == RegistrationStatus.REGISTERED;
    }

    public void approveRegistration() {
        if (status != RegistrationStatus.PENDING) {
            throw new IllegalStateException(
                "Only pending registrations can be approved."
            );
        }

        if (!event.isRegistrationOpen()) {
            throw new IllegalStateException(
                "Event registration is currently closed."
            );
        }

        status = RegistrationStatus.REGISTERED;
    }

    public void cancelRegistration() {
        if (status == RegistrationStatus.CANCELLED) {
            throw new IllegalStateException(
                "Registration is already cancelled."
            );
        }

        if (event.getStatus() != Event.EventStatus.SCHEDULED) {
            throw new IllegalStateException(
                "Registration cannot be cancelled after the event starts."
            );
        }

        if (qrPass != null && qrPass.isActive()) {
            qrPass.revoke();
        }

        status = RegistrationStatus.CANCELLED;
    }

    public QRPass createPass() {
        if (!isValid()) {
            throw new IllegalStateException(
                "Only registered guests can receive a QR pass."
            );
        }

        if (qrPass != null && qrPass.isActive()) {
            throw new IllegalStateException(
                "An active QR pass already exists."
            );
        }

        qrPass = new QRPass(this);
        return qrPass;
    }

    public QRPass reissuePass() {
        if (!isValid()) {
            throw new IllegalStateException(
                "Cannot reissue a pass for an invalid registration."
            );
        }

        if (qrPass == null || !qrPass.isActive()) {
            throw new IllegalStateException(
                "No active pass exists to reissue."
            );
        }

        qrPass.revoke();
        qrPass = new QRPass(this);

        return qrPass;
    }
}

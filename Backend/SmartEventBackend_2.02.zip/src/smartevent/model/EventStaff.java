package smartevent.model;

public class EventStaff extends UserAccount {

    public EventStaff(String userId, String username, String displayName) {
        super(userId, username, displayName);
    }
}